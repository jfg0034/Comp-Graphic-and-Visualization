#include <iostream>         
#include <cstdlib>          
#include <GL/glew.h>        
#include <GLFW/glfw3.h>
#define STB_IMAGE_IMPLEMENTATION
#include <stb_image.h>      // Image loading Utility functions

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <learnOpengl/camera.h> // Camera class


using namespace std;

/*Shader program Macro*/
#ifndef GLSL
#define GLSL(Version, Source) "#version " #Version " core \n" #Source
#endif


namespace
{
    const char* const WINDOW_TITLE = "FINAL PROJECT"; // Window title

    // Window width and height dimensions
    const int WINDOW_WIDTH = 800;
    const int WINDOW_HEIGHT = 800;

    // Struct created to store GL data to a mesh
    struct GLMesh
    {
        GLuint vao_light, vao_table, vao_tablet[3], vao_notebook[3], vao_lamp[4], vao_spen[3];
        GLuint vbo_light, vbo_table, vbo_tablet[3], vbo_notebook[3], vbo_lamp[4], vbo_spen[3];

        GLuint nVerticesLight;  // Light vertices
        GLuint nVerticesTable;  // Number of vertices for table 
        GLuint nVerticesTablet[3];
        GLuint nVerticesNotebook[3];
        GLuint nVerticesLamp[4];
        GLuint nVerticesSPen[3];
    };

    // Main GLFW window
    GLFWwindow* gWindow = nullptr;

    // Triangle mesh data
    GLMesh gMesh;

    // Texture IDs
    GLuint gTextureTable;
    GLuint gTextureTablet[3];
    GLuint gTextureNotebook[3];
    GLuint gTextureLamp[4];
    GLuint gTextureSPen[3];

    // Shader program
    GLuint gProgramId;
    GLuint gLightProgramId;

    glm::vec2 gUVScale(1.0f, 1.0f); // Scale parameter to return to normal dimension
    glm::vec2 gUVScaleTable(75.0f, 75.0f);
    GLint gTexWrapMode;

    // camera, centered and 5 units higher, noticeable on perspective view
    Camera gCamera(glm::vec3(0.0f, 2.0f, 10.0f));
    float gLastX = WINDOW_WIDTH / 2.0f;
    float gLastY = WINDOW_HEIGHT / 2.0f;
    bool gFirstMouse = true;

    // Upwards position
    glm::vec3 gCameraUp = glm::vec3(0.0f, 1.0f, 0.0f);

    // timing
    float gDeltaTime = 0.0f; // time between current frame and last frame
    float gLastFrame = 0.0f;


    bool orthographic = false;
}

// User-defined Functions:

bool UInitialize(int, char* [], GLFWwindow** window); // Initialize program
void UResizeWindow(GLFWwindow* window, int width, int height); // Set window size
void UProcessInput(GLFWwindow* window);
void UCreateMesh(GLMesh& mesh);
void UDestroyMesh(GLMesh& mesh);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId);
void UDestroyShaderProgram(GLuint programId);

// Texture functions
void UCreateTexture(const char* filename, GLuint& textureId);
void UDestroyTexture(GLuint textureId);

void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods);

// Open cylinder function
vector<GLfloat> createOpenCylinderVerts(GLfloat posX, GLfloat posY, GLfloat posZ, GLfloat topRadius, GLfloat bottomRadius, GLfloat height, GLfloat trianglePresicion, GLboolean top);

// Torus function
vector<GLfloat> createTorusVerts(GLfloat posX, GLfloat posY, GLfloat posZ, GLfloat mainRadius, GLfloat innerRadius, GLfloat trianglePresicion);



/* Vertex Shader Source Code*/
const GLchar* vertexShaderSource = GLSL(440,
    layout(location = 0) in vec3 position; // Vertex data from Vertex Attrib Pointer 0
    layout(location = 1) in vec3 normal;  // Position 1 for normals
    layout(location = 2) in vec2 textureCoordinate;  // Texture data from Vertex Attrib Pointer 2

    out vec3 vertexNormal; // For outgoing normals to fragment shader
    out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
    out vec2 vertexTextureCoordinate;

    //Global variables for the transform matrices
    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

    void main()
    {
        gl_Position = projection * view * model * vec4(position, 1.0f); // transforms vertices to clip coordinates
        vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)
        vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties 
        vertexTextureCoordinate = textureCoordinate;
    }
);

/* Fragment Shader Source Code*/
const GLchar* fragmentShaderSource = GLSL(440,

    in vec3 vertexNormal; // For incoming normals
    in vec3 vertexFragmentPos; // For incoming fragment position
    in vec2 vertexTextureCoordinate;

    out vec4 fragmentColor; // For outgoing color to the GPU

    // Uniform / Global variables for object color, light color, light position, and camera/view position
    uniform vec3 lightColor;
    uniform vec3 lightPos;
    uniform vec3 viewPosition;

    // Second light
    uniform vec3 lightColor2;
    uniform vec3 lightPos2;

    uniform sampler2D uTexture; // Useful when working with multiple textures
    uniform vec2 uvScale;

    void main()
    {
        /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

        // LIGHT 1
        //Calculate Ambient lighting*/
        float ambientStrength = 0.05f; // Set ambient or global lighting strength
        vec3 ambient = ambientStrength * lightColor; // Generate ambient light color

        //Calculate Diffuse lighting*/
        vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
        vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
        float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
        vec3 diffuse = impact * lightColor; // Generate diffuse light color

        //Calculate Specular lighting*/
        float specularIntensity = 5.0f; // Set specular light strength
        float highlightSize = 1.0f; // Set specular highlight size
        vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
        vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector
        //Calculate specular component
        float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
        vec3 specular = specularIntensity * specularComponent * lightColor;

        // Texture holds the color to be used for all three components
        vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

        // Calculate phong result
        vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;


        // LIGHT 2
        vec3 phong2 = vec3(0.0);

        if (lightColor2 != vec3(0.0)) {
            //Calculate Ambient lighting*/
            float ambientStrength2 = 0.5f; // Set ambient or global lighting strength
            vec3 ambient2 = ambientStrength2 * lightColor2; // Generate ambient light color

            //Calculate Diffuse lighting*/
            //vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
            vec3 lightDirection2 = normalize(lightPos2 - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
            float impact2 = max(dot(norm, lightDirection2), 0.0);// Calculate diffuse impact by generating dot product of normal and light
            vec3 diffuse2 = impact2 * lightColor2; // Generate diffuse light color

            //Calculate Specular lighting*/
            float specularIntensity2 = 1.0f; // Set specular light strength
            float highlightSize2 = 5.0f; // Set specular highlight size
            vec3 viewDir2 = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
            vec3 reflectDir2 = reflect(-lightDirection2, norm);// Calculate reflection vector
            //Calculate specular component
            float specularComponent2 = pow(max(dot(viewDir2, reflectDir2), 0.0), highlightSize2);
            vec3 specular2 = specularIntensity2 * specularComponent2 * lightColor2;

            // Texture holds the color to be used for all three components
            vec4 textureColor2 = texture(uTexture, vertexTextureCoordinate * uvScale);

            // Calculate phong result
            phong2 = (ambient2 + diffuse2 + specular2) * textureColor2.xyz;
        }
        phong = phong + phong2; // Both lights are combined into one phong
        fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
    }
);


/* Light Vertex Shader Source Code*/
const GLchar* lightVertexShaderSource = GLSL(440,
    layout(location = 0) in vec3 position; // VAP position 0 for vertex position data

    //Uniform / Global variables for the  transform matrices
    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;

    void main()
    {
        gl_Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
    }
);


/* Light Fragment Shader Source Code*/
const GLchar* lightFragmentShaderSource = GLSL(440,
    out vec4 fragmentColor; // For outgoing lamp color to the GPU
    uniform vec3 lampColor;

    void main()
    {
        fragmentColor = vec4(lampColor, 1.0);
    }
);


// Images are loaded with Y axis going down, but OpenGL's Y axis goes up, so let's flip it
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}


// main function
int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

    // Create the mesh
    UCreateMesh(gMesh); // Calls the function to create the Vertex Buffer Object

    // Create the shader program, otherwise exit
    if (!UCreateShaderProgram(vertexShaderSource, fragmentShaderSource, gProgramId))
        return EXIT_FAILURE;

    if (!UCreateShaderProgram(lightVertexShaderSource, lightFragmentShaderSource, gLightProgramId))
        return EXIT_FAILURE;

    // Table texture
    UCreateTexture("../images/table.jpg", gTextureTable);

    // Tablet textures
    UCreateTexture("../images/tabletside.jpg", gTextureTablet[0]); // Back and sides
    UCreateTexture("../images/tabletfront.jpg", gTextureTablet[1]); // Front
    UCreateTexture("../images/screen.jpg", gTextureTablet[2]); // Screen

    // Notebook textures
    UCreateTexture("../images/cover.jpg", gTextureNotebook[0]); // Cover
    UCreateTexture("../images/pages.jpg", gTextureNotebook[1]); // Pages
    UCreateTexture("../images/binderplastic.jpg", gTextureNotebook[2]); // Ring binders

    // Lamp textures
    UCreateTexture("../images/lampbase.jpg", gTextureLamp[0]); // Base
    UCreateTexture("../images/lamppole.jpg", gTextureLamp[1]); // Main pole
    UCreateTexture("../images/rest.jpg", gTextureLamp[2]); // Lightbulb rest
    UCreateTexture("../images/lampshade.jpg", gTextureLamp[3]); // Lamp shade

    // SPen textures
    UCreateTexture("../images/penbody.jpg", gTextureSPen[0]); // SPen body
    UCreateTexture("../images/penhead.jpg", gTextureSPen[1]); // SPen head
    UCreateTexture("../images/coppertip.jpg", gTextureSPen[2]); // SPen tip

    // Sets the background color of the window to white, one values for RGB
    glClearColor(1.0f, 1.0f, 1.0f, 1.0f);

    // render loop
    // -----------
    while (!glfwWindowShouldClose(gWindow))
    {
        // per-frame timing
        // --------------------
        float currentFrame = glfwGetTime();
        gDeltaTime = currentFrame - gLastFrame; // time passed between current frame and last frame
        gLastFrame = currentFrame;

        // input
        // -----
        UProcessInput(gWindow);

        // Render this frame
        URender();

        glfwPollEvents();
    }

    // Release mesh data once window closes
    UDestroyMesh(gMesh);

    // Release texture
    UDestroyTexture(gTextureTable);
    UDestroyTexture(gTextureTablet[0]);
    UDestroyTexture(gTextureTablet[1]);
    UDestroyTexture(gTextureTablet[2]);
    UDestroyTexture(gTextureNotebook[0]);
    UDestroyTexture(gTextureNotebook[1]);
    UDestroyTexture(gTextureNotebook[2]);
    UDestroyTexture(gTextureLamp[0]);
    UDestroyTexture(gTextureLamp[1]);
    UDestroyTexture(gTextureLamp[2]);
    UDestroyTexture(gTextureLamp[3]);
    UDestroyTexture(gTextureSPen[0]);
    UDestroyTexture(gTextureSPen[1]);
    UDestroyTexture(gTextureSPen[2]);
    ;

    // Release shader program
    UDestroyShaderProgram(gProgramId);
    UDestroyShaderProgram(gLightProgramId);

    exit(EXIT_SUCCESS); // Terminates the program successfully
}


// Initialize GLFW, GLEW, and create a window
bool UInitialize(int argc, char* argv[], GLFWwindow** window)
{
    // GLFW: initialize and configure
    // ------------------------------
    glfwInit();
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 4);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

    // GLFW: window creation
    // ---------------------
    * window = glfwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create GLFW window" << std::endl;
        glfwTerminate();
        return false;
    }
    glfwMakeContextCurrent(*window);
    glfwSetFramebufferSizeCallback(*window, UResizeWindow);
    // Mouse callbacks
    glfwSetCursorPosCallback(*window, UMousePositionCallback);
    glfwSetScrollCallback(*window, UMouseScrollCallback);
    glfwSetMouseButtonCallback(*window, UMouseButtonCallback);

    // tell GLFW to get mouse input, disables cursor appearance
    glfwSetInputMode(*window, GLFW_CURSOR, GLFW_CURSOR_DISABLED);

    // GLEW: initialize
    // ----------------
    // Note: if using GLEW version 1.13 or earlier
    glewExperimental = GL_TRUE;
    GLenum GlewInitResult = glewInit();

    if (GLEW_OK != GlewInitResult)
    {
        std::cerr << glewGetErrorString(GlewInitResult) << std::endl;
        return false;
    }

    // Displays GPU OpenGL version
    cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << endl;

    return true;
}


// process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
void UProcessInput(GLFWwindow* window)
{
    // speed of camera
    static const float cameraSpeed = 2.5f;

    float cameraOffset = cameraSpeed * gDeltaTime;

    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true); // ESC key exits window

    // WASD keyboard events using learnOpengl camera class
    if (glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS)
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS)
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    if (glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS)
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);

    // Uses local variables, gCamera.ProcessKeyboard does not support other movements than the former ones
    if (glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS)
        gCamera.Position += cameraOffset * gCameraUp;
    if (glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS)
        gCamera.Position -= cameraOffset * gCameraUp;

    // Changes ortographic display to perspective
    if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
        orthographic = false;
    // Changes ortographic display to ortographic
    if (glfwGetKey(window, GLFW_KEY_O) == GLFW_PRESS)
        orthographic = true;
}

// glfw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(GLFWwindow* window, int width, int height)
{
    glViewport(0, 0, width, height);
}

// glfw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void UMousePositionCallback(GLFWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gLastX = xpos;
        gLastY = ypos;
        gFirstMouse = false;
    }

    float xoffset = xpos - gLastX;
    float yoffset = gLastY - ypos; // reversed since y-coordinates go from bottom to top

    gLastX = xpos;
    gLastY = ypos;

    gCamera.ProcessMouseMovement(xoffset, yoffset);
}

// glfw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void UMouseScrollCallback(GLFWwindow* window, double xoffset, double yoffset)
{
    gCamera.ProcessMouseScroll(yoffset);
}

// glfw: handle mouse button events
// --------------------------------
void UMouseButtonCallback(GLFWwindow* window, int button, int action, int mods)
{
    switch (button)
    {
    case GLFW_MOUSE_BUTTON_LEFT:
    {
        if (action == GLFW_PRESS)
            cout << "Left mouse button pressed" << endl;
        else
            cout << "Left mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_MIDDLE:
    {
        if (action == GLFW_PRESS)
            cout << "Middle mouse button pressed" << endl;
        else
            cout << "Middle mouse button released" << endl;
    }
    break;

    case GLFW_MOUSE_BUTTON_RIGHT:
    {
        if (action == GLFW_PRESS)
            cout << "Right mouse button pressed" << endl;
        else
            cout << "Right mouse button released" << endl;
    }
    break;

    default:
        cout << "Unhandled mouse button event" << endl;
        break;
    }
}

// Functioned called to render a frame
void URender()
{
    // Local variables
    glm::mat4 scale;
    glm::mat4 rotationx;
    glm::mat4 rotationy;
    glm::mat4 rotationz;
    glm::mat4 rotation;
    glm::mat4 translation;
    glm::mat4 model;
    glm::mat4 projection;
    glm::mat4 view;

    const glm::vec3 cameraPosition = gCamera.Position;

    // Enable z-depth
    glEnable(GL_DEPTH_TEST);

    // Clear the frame and z buffers
    glClearColor(0.1f, 0.1f, 0.1f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // GLOBAL ATTRIBUTES
    // camera/view transformation
    view = gCamera.GetViewMatrix();

    if (!orthographic) {
        // Creates a perspective projection
        projection = glm::perspective(glm::radians(gCamera.Zoom), (GLfloat)WINDOW_WIDTH / (GLfloat)WINDOW_HEIGHT, 1.0f, 100.0f);
    }
    else {
        // Creates orthographic projection
        projection = glm::ortho(-6.0f, 6.0f, -6.0f, 6.0f, 0.1f, 100.0f);
    }

    // SET LIGHTS.........
    // ...................

    // LIGHT 1

    glm::vec3 gLight1Color(0.3f, 0.2f, 0.0f); // amber light

    // Light position and scale
    glm::vec3 gLight1Position(-2.0f, 4.2f, -2.0f);
    glm::vec3 gLight1Scale(0.2f, 0.2f, 0.2f);

    glUseProgram(gLightProgramId);
    glBindVertexArray(gMesh.vao_light);

    //Transform the smaller cube used as a visual que for the light source
    model = glm::translate(gLight1Position) * glm::scale(gLight1Scale);

    // Reference matrix uniforms from the Lamp Shader program
    GLint modelLoc = glGetUniformLocation(gLightProgramId, "model");
    GLint viewLoc = glGetUniformLocation(gLightProgramId, "view");
    GLint projLoc = glGetUniformLocation(gLightProgramId, "projection");
    GLint lampColorLoc = glGetUniformLocation(gLightProgramId, "lampColor");

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    glUniform3f(lampColorLoc, 3 * gLight1Color.r, 3 * gLight1Color.g, 3 * gLight1Color.b); // Factor 3 increases lightbulb color but does not interfer with light

    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVerticesLight);


    // LIGHT 2

    glm::vec3 gLight2Color(0.6f, 0.6f, 0.6f); // white light

    // Light position and scale
    glm::vec3 gLight2Position(4.0f, 4.5f, 4.0f);
    glm::vec3 gLight2Scale(0.2f, 0.2f, 0.2f);

    //Transform the smaller cube used as a visual que for the light source
    model = glm::translate(gLight2Position) * glm::scale(gLight2Scale);

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    glUniform3f(lampColorLoc, 2 * gLight2Color.r, 2 * gLight2Color.g, 2 * gLight2Color.b);

    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVerticesLight);


    // OBJECTS..........
    // .................

    // Set the shader to be used
    glUseProgram(gProgramId);

    // Retrieves and passes transform matrices to the shader program
    modelLoc = glGetUniformLocation(gProgramId, "model");
    viewLoc = glGetUniformLocation(gProgramId, "view");
    projLoc = glGetUniformLocation(gProgramId, "projection");
    GLint UVScaleLoc = glGetUniformLocation(gProgramId, "uvScale");
    GLuint textureLoc = glGetUniformLocation(gProgramId, "uTexture");
    // Reference matrix uniforms from the Shader program for the light color, light position, and camera position
    GLint lightColorLoc = glGetUniformLocation(gProgramId, "lightColor");
    GLint lightPositionLoc = glGetUniformLocation(gProgramId, "lightPos");
    GLint viewPositionLoc = glGetUniformLocation(gProgramId, "viewPosition");
    // Reference matrix uniforms for second light
    GLint lightColorLoc2 = glGetUniformLocation(gProgramId, "lightColor2");
    GLint lightPositionLoc2 = glGetUniformLocation(gProgramId, "lightPos2");
    GLint viewPositionLoc2 = glGetUniformLocation(gProgramId, "viewPosition2");

    // view and projection uniforms do not change from object to object
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Pass color, light, and camera data to the Shader program's corresponding uniforms
    glUniform3f(lightColorLoc, gLight1Color.r, gLight1Color.g, gLight1Color.b);
    glUniform3f(lightColorLoc2, gLight2Color.r, gLight2Color.g, gLight2Color.b);

    glUniform3f(lightPositionLoc, gLight1Position.x, gLight1Position.y, gLight1Position.z);
    glUniform3f(lightPositionLoc2, gLight2Position.x, gLight2Position.y, gLight2Position.z);
    
    glUniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z); // Viiew is the same for all


    // TABLE.....
    //...........
    // Activate table vbos in vao_table
    glBindVertexArray(gMesh.vao_table);

    // Scale, Rotation and translation matrices
    scale = glm::scale(glm::vec3(4.0f, 4.0f, 1.0f));
    // Rotation in 3 axis
    rotationx = glm::rotate(glm::radians(90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
    rotationy = glm::rotate(glm::radians(0.0f), glm::vec3(0.0f, 1.0f, 0.0f));
    rotationz = glm::rotate(glm::radians(0.0f), glm::vec3(0.0f, 0.0f, 1.0f));
    rotation = rotationx * rotationy * rotationz;
    // Relocation
    translation = glm::translate(glm::vec3(0.0f, 0.0f, 0.0f));

    // Model matrix: Transformations are applied right-to-left order
    model = translation * rotation * scale;
     
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model)); // Passes model matrix of current object to the shader program
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScaleTable)); // Passes uniform with texture scale parameters to enlarge object
    glUniform1i(textureLoc, 0); // Loads uniform sampler into texture 0

    glActiveTexture(GL_TEXTURE0); // Selects texture to be activated
    glBindTexture(GL_TEXTURE_2D, gTextureTable); // Activates texture

    // Draws table
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVerticesTable);


     // TABLET.......
    // .............
    // Scale, Rotation and translation matrices
    scale = glm::scale(glm::vec3(2.9f, 1.9f, 0.6f));
    // Rotation in 3 axis
    rotationx = glm::rotate(glm::radians(-90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
    rotationy = glm::rotate(glm::radians(0.0f), glm::vec3(0.0f, 1.0f, 0.0f));
    rotationz = glm::rotate(glm::radians(30.0f), glm::vec3(0.0f, 0.0f, 1.0f));
    rotation = rotationx * rotationy * rotationz;
    //Relocation
    translation = glm::translate(glm::vec3(-1.5f, 0.0f, 1.5f));

    // Model matrix
    model = translation * rotation * scale;

    // Scale of textures in the object will remain 1:1 
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale)); // Uniform selected has normalized parameters, so no texture deformation will occur
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model)); // Passes model matrix of current object to the shader program

    // Tablet, back and border
    glBindVertexArray(gMesh.vao_tablet[0]);
    glUniform1i(textureLoc, 0); // Loads uniform sampler into texture 4
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureTablet[0]);
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVerticesTablet[0]); // Draws back of tablet

    // Tablet, front edges
    glBindVertexArray(gMesh.vao_tablet[1]);
    glUniform1i(textureLoc, 5); // Loads uniform sampler into texture 5
    glActiveTexture(GL_TEXTURE5);
    glBindTexture(GL_TEXTURE_2D, gTextureTablet[1]);
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVerticesTablet[1]); // Draws front of tablet

    // Tablet, screen
    glBindVertexArray(gMesh.vao_tablet[2]);
    glUniform1i(textureLoc, 6); // Loads uniform sampler into texture 6
    glActiveTexture(GL_TEXTURE6);
    glBindTexture(GL_TEXTURE_2D, gTextureTablet[2]);
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVerticesTablet[2]); // Draws screen of tablet


    // NOTEBOOK.......
    // ...............
    // Scale, Rotation and translation matrices
    scale = glm::scale(glm::vec3(1.6f, 2.1f, 2.0f));
    // Rotation in 3 axis
    rotationx = glm::rotate(glm::radians(-90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
    rotationy = glm::rotate(glm::radians(2.2f), glm::vec3(0.0f, 1.0f, 0.0f));
    rotationz = glm::rotate(glm::radians(-10.0f), glm::vec3(0.0f, 0.0f, 1.0f));
    rotation = rotationx * rotationy * rotationz;
    //Relocation
    translation = glm::translate(glm::vec3(1.5f, 0.03f, 0.0f));

    // Model matrix
    model = translation * rotation * scale;

    // Scale of textures in the object will remain 1:1 
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale)); // Uniform selected has normalized parameters, so no texture deformation will occur
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model)); // Passes model matrix of current object to the shader program

    // Notebook, covers
    glBindVertexArray(gMesh.vao_notebook[0]);
    glUniform1i(textureLoc, 0); // Loads uniform sampler into texture 0
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureNotebook[0]);
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVerticesNotebook[0]); // Draws covers of notebook

    // Notebook, paper sides
    glBindVertexArray(gMesh.vao_notebook[1]);
    glUniform1i(textureLoc, 1); // Loads uniform sampler into texture 1
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, gTextureNotebook[1]);
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVerticesNotebook[1]); // Draws sides of notebook

    // Notebook, ring binders. For an easier manipulation it will be allocated and scaled separately
    // Scale, Rotation and translation matrices
    scale = glm::scale(glm::vec3(0.1f, 0.1f, 0.1f));
    // Rotation in 3 axis
    rotationx = glm::rotate(glm::radians(0.0f), glm::vec3(1.0f, 0.0f, 0.0f));
    rotationy = glm::rotate(glm::radians(-10.0f), glm::vec3(0.0f, 1.0f, 0.0f));
    rotationz = glm::rotate(glm::radians(0.0f), glm::vec3(0.0f, 0.0f, 1.0f));
    rotation = rotationx * rotationy * rotationz;
    //Relocation
    translation = glm::translate(glm::vec3(0.81f, 0.16f, -1.1));
    // Model matrix
    model = translation * rotation * scale;
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model)); // Passes model matrix of current object to the shader program
    glBindVertexArray(gMesh.vao_notebook[2]);
    glUniform1i(textureLoc, 2); // Loads uniform sampler into texture 1
    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D, gTextureNotebook[2]);
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVerticesNotebook[2]); // Draws sides of notebook


    // LAMP...........
    // ...............
    // Scale, Rotation and translation matrices
    scale = glm::scale(glm::vec3(1.25f, 1.25f, 2.0f));
    // Rotation in 3 axis
    rotationx = glm::rotate(glm::radians(-90.0f), glm::vec3(1.0f, 0.0f, 0.0f));
    rotationy = glm::rotate(glm::radians(0.0f), glm::vec3(0.0f, 1.0f, 0.0f));
    rotationz = glm::rotate(glm::radians(90.0f), glm::vec3(0.0f, 0.0f, 1.0f));
    rotation = rotationx * rotationy * rotationz;
    //Relocation
    translation = glm::translate(glm::vec3(-2.0f, 0.0f, -2.0f));

    // Model matrix
    model = translation * rotation * scale;

    // Scale of textures in the object will remain 1:1 
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale)); // Uniform selected has normalized parameters, so no texture deformation will occur
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model)); // Passes model matrix of current object to the shader program

    // Lamp base
    glBindVertexArray(gMesh.vao_lamp[0]);
    glUniform1i(textureLoc, 0); // Loads uniform sampler into texture 0
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureLamp[0]);
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVerticesLamp[0]); // Draws lamp base

    // Lamp pole
    glBindVertexArray(gMesh.vao_lamp[1]);
    glUniform1i(textureLoc, 1); // Loads uniform sampler into texture 1
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, gTextureLamp[1]);
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVerticesLamp[1]); // Draws lamp pole

    // Lamp, lightbulb rest
    glBindVertexArray(gMesh.vao_lamp[2]);
    glUniform1i(textureLoc, 2); // Loads uniform sampler into texture 2
    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D, gTextureLamp[2]);
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVerticesLamp[2]); // Draws lightbulb rest

    // Lamp shade
    glBindVertexArray(gMesh.vao_lamp[3]);
    glUniform1i(textureLoc, 3); // Loads uniform sampler into texture 3
    glActiveTexture(GL_TEXTURE3);
    glBindTexture(GL_TEXTURE_2D, gTextureLamp[3]);
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVerticesLamp[3]); // Draws lamp shade


    // SPEN...........
    // ...............
    // Scale, Rotation and translation matrices
    scale = glm::scale(glm::vec3(1.0f, 1.0f, 2.0f));
    // Rotation in 3 axis
    rotationx = glm::rotate(glm::radians(-1.0f), glm::vec3(1.0f, 0.0f, 0.0f));
    rotationy = glm::rotate(glm::radians(-30.0f), glm::vec3(0.0f, 1.0f, 0.0f));
    rotationz = glm::rotate(glm::radians(0.0f), glm::vec3(0.0f, 0.0f, 1.0f));
    rotation = rotationx * rotationy * rotationz;
    //Relocation
    translation = glm::translate(glm::vec3(2.1f, 0.262f, -0.7f));

    // Model matrix
    model = translation * rotation * scale;

    // Scale of textures in the object will remain 1:1 
    glUniform2fv(UVScaleLoc, 1, glm::value_ptr(gUVScale)); // Uniform selected has normalized parameters, so no texture deformation will occur
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model)); // Passes model matrix of current object to the shader program

    // SPen body
    glBindVertexArray(gMesh.vao_spen[0]);
    glUniform1i(textureLoc, 0); // Loads uniform sampler into texture 0
    glActiveTexture(GL_TEXTURE0);
    glBindTexture(GL_TEXTURE_2D, gTextureSPen[0]);
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVerticesSPen[0]); // Draws SPen body

    // SPen head
    glBindVertexArray(gMesh.vao_spen[1]);
    glUniform1i(textureLoc, 1); // Loads uniform sampler into texture 1
    glActiveTexture(GL_TEXTURE1);
    glBindTexture(GL_TEXTURE_2D, gTextureSPen[1]);
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVerticesSPen[1]); // Draws SPen head

    // SPen tip
    glBindVertexArray(gMesh.vao_spen[2]);
    glUniform1i(textureLoc, 2); // Loads uniform sampler into texture 2
    glActiveTexture(GL_TEXTURE2);
    glBindTexture(GL_TEXTURE_2D, gTextureSPen[2]);
    glDrawArrays(GL_TRIANGLES, 0, gMesh.nVerticesSPen[2]); // Draws SPen tip


    // Deactivate the Vertex Array Object
    glBindVertexArray(0);

    // glfw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
    glfwSwapBuffers(gWindow);    // Flips the the back buffer with the front buffer every frame.

}


// Implements the UCreateMesh function
void UCreateMesh(GLMesh& mesh)
{
    // All objects will have a similar structure defined by location and texture
    const GLuint floatsPerVertex = 3; // Number of coordinates per vertex
    const GLuint floatsPerNormal = 3; // Normal coordinates
    const GLuint floatsPerTexUV = 2;  // (u, v)

    // Open Cylinder variables
    GLfloat posX;
    GLfloat posY;
    GLfloat posZ;
    GLfloat topRadius;
    GLfloat bottomRadius;
    GLfloat height;
    GLfloat presicion;

    // Torus additional variables
    GLfloat mainRadius;
    GLfloat innerRadius;


    // LIGHT..............
    // ...................
    GLfloat lightVerts[] = {
      //Positions          
      //Back Face            .
       -0.5f, -0.5f, -0.5f,  
        0.5f, -0.5f, -0.5f,  
        0.5f,  0.5f, -0.5f,  
        0.5f,  0.5f, -0.5f,  
       -0.5f,  0.5f, -0.5f,  
       -0.5f, -0.5f, -0.5f,  

      //Front Face         
       -0.5f, -0.5f,  0.5f,  
        0.5f, -0.5f,  0.5f,  
        0.5f,  0.5f,  0.5f,  
        0.5f,  0.5f,  0.5f,  
       -0.5f,  0.5f,  0.5f,  
       -0.5f, -0.5f,  0.5f,  

      //Left Face          
       -0.5f,  0.5f,  0.5f, 
       -0.5f,  0.5f, -0.5f, 
       -0.5f, -0.5f, -0.5f, 
       -0.5f, -0.5f, -0.5f, 
       -0.5f, -0.5f,  0.5f, 
       -0.5f,  0.5f,  0.5f, 

      //Right Face         
        0.5f,  0.5f,  0.5f,  
        0.5f,  0.5f, -0.5f,  
        0.5f, -0.5f, -0.5f,  
        0.5f, -0.5f, -0.5f,  
        0.5f, -0.5f,  0.5f,  
        0.5f,  0.5f,  0.5f,  

      //Bottom Face        
       -0.5f, -0.5f, -0.5f,  
        0.5f, -0.5f, -0.5f,  
        0.5f, -0.5f,  0.5f,  
        0.5f, -0.5f,  0.5f,  
       -0.5f, -0.5f,  0.5f,  
       -0.5f, -0.5f, -0.5f,  

      //Top Face           
       -0.5f,  0.5f, -0.5f,  
        0.5f,  0.5f, -0.5f,  
        0.5f,  0.5f,  0.5f,  
        0.5f,  0.5f,  0.5f,  
       -0.5f,  0.5f,  0.5f,  
       -0.5f,  0.5f, -0.5f,  
    };

    mesh.nVerticesLight = sizeof(lightVerts) / (sizeof(lightVerts[0]) * (floatsPerVertex));
    GLint stride = sizeof(float) * (floatsPerVertex);

    glGenVertexArrays(1, &mesh.vao_light);
    glBindVertexArray(mesh.vao_light);

    glGenBuffers(1, &mesh.vbo_light);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo_light); // Activates the buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(lightVerts), lightVerts, GL_STATIC_DRAW);

    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);


    // OBJECTS........
    // ...............

    // Strides between vertex coordinates for objects (contain position, normals and texture)
    stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerTexUV);


    // TABLE........
    // .............
    GLfloat vertsTable[] =
    {
        // Position x, y, z     // Normals           // Texture coordinate u, v
         1.0f,  1.0f, 0.0f,     0.0f, 0.0f, 1.0f,    1.0f, 1.0f,
         1.0f, -1.0f, 0.0f,     0.0f, 0.0f, 1.0f,    1.0f, 0.0f,
        -1.0f, -1.0f, 0.0f,     0.0f, 0.0f, 1.0f,    0.0f, 0.0f,
         1.0f,  1.0f, 0.0f,     0.0f, 0.0f, 1.0f,    1.0f, 1.0f,
        -1.0f, -1.0f, 0.0f,     0.0f, 0.0f, 1.0f,    0.0f, 0.0f,
        -1.0f,  1.0f, 0.0f,     0.0f, 0.0f, 1.0f,    0.0f, 1.0f
    };
    mesh.nVerticesTable = sizeof(vertsTable) / (sizeof(vertsTable[0]) * (floatsPerVertex + floatsPerNormal + floatsPerTexUV));

    glGenVertexArrays(1, &mesh.vao_table); // Generates vao
    glBindVertexArray(mesh.vao_table); // Activates vao

    glGenBuffers(1, &mesh.vbo_table); // Generates vbo
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo_table); // Activates buffer
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertsTable), vertsTable, GL_STATIC_DRAW); // Sends data to GPU

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, floatsPerTexUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);



    // TABLET.........
    // ...............

    // Back and border surfaces
    GLfloat tabletBackVerts[] = {
        // Position x, y, z     // Normals           // Texture coordinate u, v
        // Bottom
         0.5f,  0.5f, 0.0f,     0.0f, 0.0f, -1.0f,    1.0f, 1.0f,//0
         0.5f, -0.5f, 0.0f,     0.0f, 0.0f, -1.0f,    1.0f, 0.0f,//1
        -0.5f, -0.5f, 0.0f,     0.0f, 0.0f, -1.0f,    0.0f, 0.0f,//2
         0.5f,  0.5f, 0.0f,     0.0f, 0.0f, -1.0f,    1.0f, 1.0f,//0
        -0.5f, -0.5f, 0.0f,     0.0f, 0.0f, -1.0f,    0.0f, 0.0f,//2
        -0.5f,  0.5f, 0.0f,     0.0f, 0.0f, -1.0f,    0.0f, 1.0f,//3
        // Border 1
         0.5f, -0.5f, 0.0f,     1.0f, 0.0f, 0.0f,     0.0f, 0.0f,//1
         0.5f,  0.5f, 0.0f,     1.0f, 0.0f, 0.0f,     1.0f, 0.0f,//0
         0.5f,  0.5f, 0.1f,     1.0f, 0.0f, 0.0f,     1.0f, 0.1f,//4
         0.5f, -0.5f, 0.0f,     1.0f, 0.0f, 0.0f,     0.0f, 0.0f,//1
         0.5f,  0.5f, 0.1f,     1.0f, 0.0f, 0.0f,     1.0f, 0.1f,//4
         0.5f, -0.5f, 0.1f,     1.0f, 0.0f, 0.0f,     0.0f, 0.1f,//5
        // Border 2
        -0.5f, -0.5f, 0.0f,     0.0f, -1.0f, 0.0f,    0.0f, 0.0f,//2
         0.5f, -0.5f, 0.0f,     0.0f, -1.0f, 0.0f,    1.0f, 0.0f,//1
         0.5f, -0.5f, 0.1f,     0.0f, -1.0f, 0.0f,    1.0f, 0.1f,//5
        -0.5f, -0.5f, 0.0f,     0.0f, -1.0f, 0.0f,    0.0f, 0.0f,//2
         0.5f, -0.5f, 0.1f,     0.0f, -1.0f, 0.0f,    1.0f, 0.1f,//5
        -0.5f, -0.5f, 0.1f,     0.0f, -1.0f, 0.0f,    0.0f, 0.1f,//6
        // Border 3
        -0.5f,  0.5f, 0.0f,     -1.0f, 0.0f, 0.0f,    0.0f, 0.0f,//3
        -0.5f, -0.5f, 0.0f,     -1.0f, 0.0f, 0.0f,    1.0f, 0.0f,//2
        -0.5f, -0.5f, 0.1f,     -1.0f, 0.0f, 0.0f,    1.0f, 0.1f,//6
        -0.5f,  0.5f, 0.0f,     -1.0f, 0.0f, 0.0f,    0.0f, 0.0f,//3
        -0.5f, -0.5f, 0.1f,     -1.0f, 0.0f, 0.0f,    1.0f, 0.1f,//6
        -0.5f,  0.5f, 0.1f,     -1.0f, 0.0f, 0.0f,    0.0f, 0.1f,//7
        // Border 4
         0.5f,  0.5f, 0.0f,     0.0f, 1.0f, 0.0f,     0.0f, 0.0f,//0
        -0.5f,  0.5f, 0.0f,     0.0f, 1.0f, 0.0f,     1.0f, 0.0f,//3
        -0.5f,  0.5f, 0.1f,     0.0f, 1.0f, 0.0f,     1.0f, 0.1f,//7
         0.5f,  0.5f, 0.0f,     0.0f, 1.0f, 0.0f,     0.0f, 0.0f,//0
        -0.5f,  0.5f, 0.1f,     0.0f, 1.0f, 0.0f,     1.0f, 0.1f,//7
         0.5f,  0.5f, 0.1f,     0.0f, 1.0f, 0.0f,     0.0f, 0.1f,//4
    };

    mesh.nVerticesTablet[0] = sizeof(tabletBackVerts) / (sizeof(tabletBackVerts[0]) * (floatsPerVertex + floatsPerNormal + floatsPerTexUV));

    glGenVertexArrays(1, &mesh.vao_tablet[0]);
    glBindVertexArray(mesh.vao_tablet[0]);

    glGenBuffers(1, &mesh.vbo_tablet[0]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo_tablet[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(tabletBackVerts), tabletBackVerts, GL_STATIC_DRAW);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, floatsPerTexUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);
        

    GLfloat tabletFrontEdgeVerts[] = {
        // Edge 1
         0.5f, -0.5f, 0.1f,      0.0f, 0.0f, 1.0f,    0.0f, 0.0f,//5
         0.5f,  0.5f, 0.1f,      0.0f, 0.0f, 1.0f,    1.0f, 0.0f,//4
         0.45f,  0.45f, 0.1f,    0.0f, 0.0f, 1.0f,    1.0f, 0.05f,//8
         0.5f, -0.5f, 0.1f,      0.0f, 0.0f, 1.0f,    0.0f, 0.0f,//5
         0.45f,  0.45f, 0.1f,    0.0f, 0.0f, 1.0f,    1.0f, 0.05f,//8
         0.45f, -0.45f, 0.1f,    0.0f, 0.0f, 1.0f,    0.0f, 0.05f,//9
        // Edge 2
        -0.5f, -0.5f, 0.1f,      0.0f, 0.0f, 1.0f,    0.0f, 0.0f,//6 
         0.5f, -0.5f, 0.1f,      0.0f, 0.0f, 1.0f,    1.0f, 0.0f,//5
         0.45f, -0.45f, 0.1f,    0.0f, 0.0f, 1.0f,    1.0f, 0.05f,//9
        -0.5f, -0.5f, 0.1f,      0.0f, 0.0f, 1.0f,    0.0f, 0.0f,//6
         0.45f, -0.45f, 0.1f,    0.0f, 0.0f, 1.0f,    1.0f, 0.05f,//9
        -0.45f, -0.45f, 0.1f,    0.0f, 0.0f, 1.0f,    0.0f, 0.05f,//10
        // Edge 3
        -0.5f,  0.5f, 0.1f,      0.0f, 0.0f, 1.0f,    0.0f, 0.0f,//7
        -0.5f, -0.5f, 0.1f,      0.0f, 0.0f, 1.0f,    1.0f, 0.0f,//6
        -0.45f, -0.45f, 0.1f,    0.0f, 0.0f, 1.0f,    1.0f, 0.05f,//10
        -0.5f,  0.5f, 0.1f,      0.0f, 0.0f, 1.0f,    0.0f, 0.0f,//7
        -0.45f, -0.45f, 0.1f,    0.0f, 0.0f, 1.0f,    1.0f, 0.05f,//10
        -0.45f,  0.45f, 0.1f,    0.0f, 0.0f, 1.0f,    0.0f, 0.05f,//11
        // Edge 4
         0.5f,  0.5f, 0.1f,      0.0f, 0.0f, 1.0f,    0.0f, 0.0f,//4
        -0.5f,  0.5f, 0.1f,      0.0f, 0.0f, 1.0f,    1.0f, 0.0f,//7
        -0.45f,  0.45f, 0.1f,    0.0f, 0.0f, 1.0f,    1.0f, 0.05f,//11
         0.5f,  0.5f, 0.1f,      0.0f, 0.0f, 1.0f,    0.0f, 0.0f,//4
        -0.45f,  0.45f, 0.1f,    0.0f, 0.0f, 1.0f,    1.0f, 0.05f,//11
         0.45f,  0.45f, 0.1f,    0.0f, 0.0f, 1.0f,    0.0f, 0.05f,//8
    };

    mesh.nVerticesTablet[1] = sizeof(tabletFrontEdgeVerts) / (sizeof(tabletFrontEdgeVerts[0]) * (floatsPerVertex + floatsPerNormal + floatsPerTexUV));

    glGenVertexArrays(1, &mesh.vao_tablet[1]);
    glBindVertexArray(mesh.vao_tablet[1]);

    glGenBuffers(1, &mesh.vbo_tablet[1]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo_tablet[1]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(tabletFrontEdgeVerts), tabletFrontEdgeVerts, GL_STATIC_DRAW);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, floatsPerTexUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);


    GLfloat tabletScreenVerts[] = {
       -0.45f, -0.45f, 0.1f,    0.0f, 0.0f, 1.0f,    0.0f, 0.0f,//10
        0.45f, -0.45f, 0.1f,    0.0f, 0.0f, 1.0f,    1.0f, 0.0f,//9
        0.45f,  0.45f, 0.1f,    0.0f, 0.0f, 1.0f,    1.0f, 1.0f,//8
       -0.45f, -0.45f, 0.1f,    0.0f, 0.0f, 1.0f,    0.0f, 0.0f,//10
        0.45f,  0.45f, 0.1f,    0.0f, 0.0f, 1.0f,    1.0f, 1.0f,//8
       -0.45f,  0.45f, 0.1f,    0.0f, 0.0f, 1.0f,    0.0f, 1.0f,//11
    };

    mesh.nVerticesTablet[2] = sizeof(tabletScreenVerts) / (sizeof(tabletScreenVerts[0]) * (floatsPerVertex + floatsPerNormal + floatsPerTexUV));

    glGenVertexArrays(1, &mesh.vao_tablet[2]);
    glBindVertexArray(mesh.vao_tablet[2]);

    glGenBuffers(1, &mesh.vbo_tablet[2]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo_tablet[2]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(tabletScreenVerts), tabletScreenVerts, GL_STATIC_DRAW);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, floatsPerTexUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);



    // NOTEBOOK.........
    // .................

    // Back and border surfaces
    GLfloat notebookCoverVerts[] = {
        // Position x, y, z     // Normals           // Texture coordinate u, v
        // Bottom
         0.5f,  0.5f, 0.0f,     0.0f, 0.0f, -1.0f,    1.0f, 1.0f,//0
         0.5f, -0.5f, 0.0f,     0.0f, 0.0f, -1.0f,    1.0f, 0.0f,//1
        -0.5f, -0.5f, 0.0f,     0.0f, 0.0f, -1.0f,    0.0f, 0.0f,//2
         0.5f,  0.5f, 0.0f,     0.0f, 0.0f, -1.0f,    1.0f, 1.0f,//0
        -0.5f, -0.5f, 0.0f,     0.0f, 0.0f, -1.0f,    0.0f, 0.0f,//2
        -0.5f,  0.5f, 0.0f,     0.0f, 0.0f, -1.0f,    0.0f, 1.0f,//3
        // Top
         0.5f,  0.5f, 0.1f,     0.0f, 0.0f, 1.0f,     1.0f, 1.0f,//4
         0.5f, -0.5f, 0.1f,     0.0f, 0.0f, 1.0f,     1.0f, 0.0f,//5
        -0.5f, -0.5f, 0.1f,     0.0f, 0.0f, 1.0f,     0.0f, 0.0f,//6
         0.5f,  0.5f, 0.1f,     0.0f, 0.0f, 1.0f,     1.0f, 1.0f,//4
        -0.5f, -0.5f, 0.1f,     0.0f, 0.0f, 1.0f,     0.0f, 0.0f,//6
        -0.5f,  0.5f, 0.1f,     0.0f, 0.0f, 1.0f,     0.0f, 1.0f,//7

    };

    mesh.nVerticesNotebook[0] = sizeof(notebookCoverVerts) / (sizeof(notebookCoverVerts[0]) * (floatsPerVertex + floatsPerNormal + floatsPerTexUV));

    glGenVertexArrays(1, &mesh.vao_notebook[0]);
    glBindVertexArray(mesh.vao_notebook[0]);

    glGenBuffers(1, &mesh.vbo_notebook[0]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo_notebook[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(notebookCoverVerts), notebookCoverVerts, GL_STATIC_DRAW);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, floatsPerTexUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);


    // Pages
    GLfloat notebookSideVerts[] = {
        // Position x, y, z     // Normals           // Texture coordinate u, v
        // Side 1
         0.5f, -0.5f, 0.0f,     1.0f, 0.0f, 0.0f,     0.0f, 0.0f,//1
         0.5f,  0.5f, 0.0f,     1.0f, 0.0f, 0.0f,     1.0f, 0.0f,//0
         0.5f,  0.5f, 0.1f,     1.0f, 0.0f, 0.0f,     1.0f, 1.0f,//4
         0.5f, -0.5f, 0.0f,     1.0f, 0.0f, 0.0f,     0.0f, 0.0f,//1
         0.5f,  0.5f, 0.1f,     1.0f, 0.0f, 0.0f,     1.0f, 1.0f,//4
         0.5f, -0.5f, 0.1f,     1.0f, 0.0f, 0.0f,     0.0f, 1.0f,//5
        // Side 2
        -0.5f, -0.5f, 0.0f,     0.0f, -1.0f, 0.0f,    1.0f, 0.0f,//2
         0.5f, -0.5f, 0.0f,     0.0f, -1.0f, 0.0f,    0.0f, 0.0f,//1
         0.5f, -0.5f, 0.1f,     0.0f, -1.0f, 0.0f,    0.0f, 1.0f,//5
        -0.5f, -0.5f, 0.0f,     0.0f, -1.0f, 0.0f,    1.0f, 0.0f,//2
         0.5f, -0.5f, 0.1f,     0.0f, -1.0f, 0.0f,    0.0f, 1.0f,//5
        -0.5f, -0.5f, 0.1f,     0.0f, -1.0f, 0.0f,    1.0f, 1.0f,//6
        // Side 3
        -0.5f,  0.5f, 0.0f,     -1.0f, 0.0f, 0.0f,    0.0f, 0.0f,//3
        -0.5f, -0.5f, 0.0f,     -1.0f, 0.0f, 0.0f,    1.0f, 0.0f,//2
        -0.5f, -0.5f, 0.1f,     -1.0f, 0.0f, 0.0f,    1.0f, 1.0f,//6
        -0.5f,  0.5f, 0.0f,     -1.0f, 0.0f, 0.0f,    0.0f, 0.0f,//3
        -0.5f, -0.5f, 0.1f,     -1.0f, 0.0f, 0.0f,    1.0f, 1.0f,//6
        -0.5f,  0.5f, 0.1f,     -1.0f, 0.0f, 0.0f,    0.0f, 1.0f,//7
        // Side 4
         0.5f,  0.5f, 0.0f,     0.0f, 1.0f, 0.0f,     1.0f, 0.0f,//0
        -0.5f,  0.5f, 0.0f,     0.0f, 1.0f, 0.0f,     0.0f, 0.0f,//3
        -0.5f,  0.5f, 0.1f,     0.0f, 1.0f, 0.0f,     0.0f, 1.0f,//7
         0.5f,  0.5f, 0.0f,     0.0f, 1.0f, 0.0f,     1.0f, 0.0f,//0
        -0.5f,  0.5f, 0.1f,     0.0f, 1.0f, 0.0f,     0.0f, 1.0f,//7
         0.5f,  0.5f, 0.1f,     0.0f, 1.0f, 0.0f,     1.0f, 1.0f,//4
    };

    mesh.nVerticesNotebook[1] = sizeof(notebookSideVerts) / (sizeof(notebookSideVerts[0]) * (floatsPerVertex + floatsPerNormal + floatsPerTexUV));

    glGenVertexArrays(1, &mesh.vao_notebook[1]);
    glBindVertexArray(mesh.vao_notebook[1]);

    glGenBuffers(1, &mesh.vbo_notebook[1]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo_notebook[1]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(notebookSideVerts), notebookSideVerts, GL_STATIC_DRAW);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, floatsPerTexUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);


    // Ring binders
    posX = 0.0f;
    posY = 0.0f;
    posZ = 0.0f;
    mainRadius = 1.5f;
    innerRadius = 0.07f;
    presicion = 50.0f;

    vector<GLfloat> ringBinderVerts;
    vector<GLfloat> ringVerts1;
    vector<GLfloat> ringVerts2;
    for (int i = 0; i < 14; i++) {
        ringVerts1 = createTorusVerts(posX, posY, posZ + (1.46f * i), mainRadius, innerRadius, presicion);
        ringVerts2 = createTorusVerts(posX, posY, posZ + (1.46f * i) + 0.25f, mainRadius, innerRadius, presicion);

        ringBinderVerts.insert(ringBinderVerts.end(), ringVerts1.begin(), ringVerts1.end());
        ringBinderVerts.insert(ringBinderVerts.end(), ringVerts2.begin(), ringVerts2.end());
    }

    mesh.nVerticesNotebook[2] = size(ringBinderVerts) / (floatsPerVertex + floatsPerNormal + floatsPerTexUV);

    glGenVertexArrays(1, &mesh.vao_notebook[2]);
    glBindVertexArray(mesh.vao_notebook[2]);

    glGenBuffers(1, &mesh.vbo_notebook[2]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo_notebook[2]);
    glBufferData(GL_ARRAY_BUFFER, size(ringBinderVerts) * sizeof(ringBinderVerts[0]), &(ringBinderVerts[0]), GL_STATIC_DRAW);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, floatsPerTexUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);


    // LAMP.........
    // ...............

    // Lamp base
    GLfloat lampBaseVerts[] = {
        // Position x, y, z     // Normals           // Texture coordinate u, v
        // Bottom
         0.5f,  0.5f, 0.0f,     0.0f, 0.0f, -1.0f,    1.0f, 1.0f,//0
         0.5f, -0.5f, 0.0f,     0.0f, 0.0f, -1.0f,    1.0f, 0.0f,//1
        -0.5f, -0.5f, 0.0f,     0.0f, 0.0f, -1.0f,    0.0f, 0.0f,//2
         0.5f,  0.5f, 0.0f,     0.0f, 0.0f, -1.0f,    1.0f, 1.0f,//0
        -0.5f, -0.5f, 0.0f,     0.0f, 0.0f, -1.0f,    0.0f, 0.0f,//2
        -0.5f,  0.5f, 0.0f,     0.0f, 0.0f, -1.0f,    0.0f, 1.0f,//3
        // Border 1
         0.5f, -0.5f, 0.0f,     1.0f, 0.0f, 0.0f,     0.0f, 0.0f,//1
         0.5f,  0.5f, 0.0f,     1.0f, 0.0f, 0.0f,     1.0f, 0.0f,//0
         0.5f,  0.5f, 0.1f,     1.0f, 0.0f, 0.0f,     1.0f, 0.1f,//4
         0.5f, -0.5f, 0.0f,     1.0f, 0.0f, 0.0f,     0.0f, 0.0f,//1
         0.5f,  0.5f, 0.1f,     1.0f, 0.0f, 0.0f,     1.0f, 0.1f,//4
         0.5f, -0.5f, 0.1f,     1.0f, 0.0f, 0.0f,     0.0f, 0.1f,//5
        // Border 2
        -0.5f, -0.5f, 0.0f,     0.0f, -1.0f, 0.0f,    0.0f, 0.0f,//2
         0.5f, -0.5f, 0.0f,     0.0f, -1.0f, 0.0f,    1.0f, 0.0f,//1
         0.5f, -0.5f, 0.1f,     0.0f, -1.0f, 0.0f,    1.0f, 0.1f,//5
        -0.5f, -0.5f, 0.0f,     0.0f, -1.0f, 0.0f,    0.0f, 0.0f,//2
         0.5f, -0.5f, 0.1f,     0.0f, -1.0f, 0.0f,    1.0f, 0.1f,//5
        -0.5f, -0.5f, 0.1f,     0.0f, -1.0f, 0.0f,    0.0f, 0.1f,//6
        // Border 3
        -0.5f,  0.5f, 0.0f,     -1.0f, 0.0f, 0.0f,    0.0f, 0.0f,//3
        -0.5f, -0.5f, 0.0f,     -1.0f, 0.0f, 0.0f,    1.0f, 0.0f,//2
        -0.5f, -0.5f, 0.1f,     -1.0f, 0.0f, 0.0f,    1.0f, 0.1f,//6
        -0.5f,  0.5f, 0.0f,     -1.0f, 0.0f, 0.0f,    0.0f, 0.0f,//3
        -0.5f, -0.5f, 0.1f,     -1.0f, 0.0f, 0.0f,    1.0f, 0.1f,//6
        -0.5f,  0.5f, 0.1f,     -1.0f, 0.0f, 0.0f,    0.0f, 0.1f,//7
        // Border 4
         0.5f,  0.5f, 0.0f,     0.0f, 1.0f, 0.0f,     0.0f, 0.0f,//0
        -0.5f,  0.5f, 0.0f,     0.0f, 1.0f, 0.0f,     1.0f, 0.0f,//3
        -0.5f,  0.5f, 0.1f,     0.0f, 1.0f, 0.0f,     1.0f, 0.1f,//7
         0.5f,  0.5f, 0.0f,     0.0f, 1.0f, 0.0f,     0.0f, 0.0f,//0
        -0.5f,  0.5f, 0.1f,     0.0f, 1.0f, 0.0f,     1.0f, 0.1f,//7
         0.5f,  0.5f, 0.1f,     0.0f, 1.0f, 0.0f,     0.0f, 0.1f,//4
        // Inclined side 1
         0.5f, -0.5f, 0.1f,     0.316f, 0.0f, 0.949f,     0.0f, 0.0f,//5
         0.5f,  0.5f, 0.1f,     0.316f, 0.0f, 0.949f,     1.0f, 0.0f,//4
         0.2f,  0.2f, 0.2f,     0.316f, 0.0f, 0.949f,     0.7f, 0.5f,//8
         0.5f, -0.5f, 0.1f,     0.316f, 0.0f, 0.949f,     0.0f, 0.0f,//5
         0.2f,  0.2f, 0.2f,     0.316f, 0.0f, 0.949f,     0.7f, 0.5f,//8
         0.2f, -0.2f, 0.2f,     0.316f, 0.0f, 0.949f,     0.3f, 0.5f,//9
        // Inclined side 2
        -0.5f, -0.5f, 0.1f,     0.0f, -0.316f, 0.949f,     0.0f, 0.0f,//6
         0.5f, -0.5f, 0.1f,     0.0f, -0.316f, 0.949f,     1.0f, 0.0f,//5
         0.2f, -0.2f, 0.2f,     0.0f, -0.316f, 0.949f,     0.7f, 0.5f,//9
        -0.5f, -0.5f, 0.1f,     0.0f, -0.316f, 0.949f,     0.0f, 0.0f,//6
         0.2f, -0.2f, 0.2f,     0.0f, -0.316f, 0.949f,     0.7f, 0.5f,//9
        -0.2f, -0.2f, 0.2f,     0.0f, -0.316f, 0.949f,     0.3f, 0.5f,//10
        // Inclined side 3
        -0.5f,  0.5f, 0.1f,     -0.316f, 0.0f, 0.949f,     0.0f, 0.0f,//7
        -0.5f, -0.5f, 0.1f,     -0.316f, 0.0f, 0.949f,     1.0f, 0.0f,//6
        -0.2f, -0.2f, 0.2f,     -0.316f, 0.0f, 0.949f,     0.7f, 0.5f,//10
        -0.5f,  0.5f, 0.1f,     -0.316f, 0.0f, 0.949f,     0.0f, 0.0f,//7
        -0.2f, -0.2f, 0.2f,     -0.316f, 0.0f, 0.949f,     0.7f, 0.5f,//10
        -0.2f,  0.2f, 0.2f,     -0.316f, 0.0f, 0.949f,     0.3f, 0.5f,//11
        // Inclined side 4
         0.5f,  0.5f, 0.1f,     0.0f, 0.316f, 0.949f,     0.0f, 0.0f,//4
        -0.5f,  0.5f, 0.1f,     0.0f, 0.316f, 0.949f,     1.0f, 0.0f,//7
        -0.2f,  0.2f, 0.2f,     0.0f, 0.316f, 0.949f,     0.7f, 0.5f,//11
         0.5f,  0.5f, 0.1f,     0.0f, 0.316f, 0.949f,     0.0f, 0.0f,//4
        -0.2f,  0.2f, 0.2f,     0.0f, 0.316f, 0.949f,     0.7f, 0.5f,//11
         0.2f,  0.2f, 0.2f,     0.0f, 0.316f, 0.949f,     0.3f, 0.5f,//8
        // Top
         0.2f,  0.2f, 0.2f,     0.0f, 0.0f, 1.0f,    1.0f, 1.0f,//8
         0.2f, -0.2f, 0.2f,     0.0f, 0.0f, 1.0f,    1.0f, 0.0f,//9
        -0.2f, -0.2f, 0.2f,     0.0f, 0.0f, 1.0f,    0.0f, 0.0f,//10
         0.2f,  0.2f, 0.2f,     0.0f, 0.0f, 1.0f,    1.0f, 1.0f,//8
        -0.2f, -0.2f, 0.2f,     0.0f, 0.0f, 1.0f,    0.0f, 0.0f,//10
        -0.2f,  0.2f, 0.2f,     0.0f, 0.0f, 1.0f,    0.0f, 1.0f,//11 
    };

    mesh.nVerticesLamp[0] = sizeof(lampBaseVerts) / (sizeof(lampBaseVerts[0]) * (floatsPerVertex + floatsPerNormal + floatsPerTexUV));

    glGenVertexArrays(1, &mesh.vao_lamp[0]);
    glBindVertexArray(mesh.vao_lamp[0]);

    glGenBuffers(1, &mesh.vbo_lamp[0]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo_lamp[0]);
    glBufferData(GL_ARRAY_BUFFER, sizeof(lampBaseVerts), lampBaseVerts, GL_STATIC_DRAW);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, floatsPerTexUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);


    // Lamp Pole
    posX = 0.0f;
    posY = 0.0f;
    posZ = 0.2f;
    topRadius = 0.14f;
    bottomRadius = topRadius;
    height = 1.32f;
    presicion = 300.0f;

    vector<GLfloat> lampPoleVerts = createOpenCylinderVerts(posX, posY, posZ, topRadius, bottomRadius, height, presicion, GL_TRUE);

    mesh.nVerticesLamp[1] = size(lampPoleVerts) / (floatsPerVertex + floatsPerNormal + floatsPerTexUV);

    glGenVertexArrays(1, &mesh.vao_lamp[1]);
    glBindVertexArray(mesh.vao_lamp[1]);

    glGenBuffers(1, &mesh.vbo_lamp[1]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo_lamp[1]);
    glBufferData(GL_ARRAY_BUFFER, size(lampPoleVerts) * sizeof(lampPoleVerts[0]), &(lampPoleVerts[0]), GL_STATIC_DRAW);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, floatsPerTexUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);


    // Lamp, lightbulb rest
    posX = 0.0f;
    posY = 0.0f;
    posZ = posZ + height;
    topRadius = 0.08f;
    bottomRadius = topRadius;
    height = 0.55f;
    presicion = 300.0f;

    vector<GLfloat> lampLightRestVerts = createOpenCylinderVerts(posX, posY, posZ, topRadius, bottomRadius, height, presicion, GL_TRUE);

    mesh.nVerticesLamp[2] = size(lampLightRestVerts) / (floatsPerVertex + floatsPerNormal + floatsPerTexUV);

    glGenVertexArrays(1, &mesh.vao_lamp[2]);
    glBindVertexArray(mesh.vao_lamp[2]);

    glGenBuffers(1, &mesh.vbo_lamp[2]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo_lamp[2]);
    glBufferData(GL_ARRAY_BUFFER, size(lampLightRestVerts) * sizeof(lampLightRestVerts[0]), &(lampLightRestVerts[0]), GL_STATIC_DRAW);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, floatsPerTexUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);


    // Lamp Shade
    posX = 0.0f;
    posY = 0.0f;
    posZ = posZ + height - 0.3f;
    topRadius = 0.68f;
    bottomRadius = 0.88f;
    height = 1.15f;
    presicion = 500.0f;

    vector<GLfloat> lampShadeVerts = createOpenCylinderVerts(posX, posY, posZ, topRadius, bottomRadius, height, presicion, GL_TRUE);

    mesh.nVerticesLamp[3] = size(lampShadeVerts) / (floatsPerVertex + floatsPerNormal + floatsPerTexUV);

    glGenVertexArrays(1, &mesh.vao_lamp[3]);
    glBindVertexArray(mesh.vao_lamp[3]);

    glGenBuffers(1, &mesh.vbo_lamp[3]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo_lamp[3]);
    glBufferData(GL_ARRAY_BUFFER, size(lampShadeVerts)* sizeof(lampShadeVerts[0]), &(lampShadeVerts[0]), GL_STATIC_DRAW);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, floatsPerTexUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);


    // S PEN..........
    // ...............
    
    // Pen body
    posX = 0.0f;
    posY = 0.0f;
    posZ = 0.0f;
    topRadius = 0.05f;
    bottomRadius = topRadius;
    height = 0.7f;
    presicion = 100.0f;

    vector<GLfloat> SPenBodyVerts = createOpenCylinderVerts(posX, posY, posZ, topRadius, bottomRadius, height, presicion, GL_FALSE);

    mesh.nVerticesSPen[0] = size(SPenBodyVerts) / (floatsPerVertex + floatsPerNormal + floatsPerTexUV);

    glGenVertexArrays(1, &mesh.vao_spen[0]);
    glBindVertexArray(mesh.vao_spen[0]);

    glGenBuffers(1, &mesh.vbo_spen[0]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo_spen[0]);
    glBufferData(GL_ARRAY_BUFFER, size(SPenBodyVerts) * sizeof(SPenBodyVerts[0]), &(SPenBodyVerts[0]), GL_STATIC_DRAW);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, floatsPerTexUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);


    // Pen head
    posX = 0.0f;
    posY = 0.0f;
    posZ = height;
    topRadius = 0.015f;
    bottomRadius = 0.05f;
    height = 0.05f;
    presicion = 300.0f;

    vector<GLfloat> SPenHeadVerts = createOpenCylinderVerts(posX, posY, posZ, topRadius, bottomRadius, height, presicion, GL_TRUE);

    mesh.nVerticesSPen[1] = size(SPenHeadVerts) / (floatsPerVertex + floatsPerNormal + floatsPerTexUV);

    glGenVertexArrays(1, &mesh.vao_spen[1]);
    glBindVertexArray(mesh.vao_spen[1]);

    glGenBuffers(1, &mesh.vbo_spen[1]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo_spen[1]);
    glBufferData(GL_ARRAY_BUFFER, size(SPenHeadVerts) * sizeof(SPenHeadVerts[0]), &(SPenHeadVerts[0]), GL_STATIC_DRAW);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, floatsPerTexUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);


    // Pen tip
    posX = 0.0f;
    posY = 0.0f;
    posZ = posZ + height;
    topRadius = 0.004f;
    bottomRadius = 0.01f;
    height = 0.015f;
    presicion = 300.0f;

    vector<GLfloat> SPenTipVerts = createOpenCylinderVerts(posX, posY, posZ, topRadius, bottomRadius, height, presicion, GL_TRUE);

    mesh.nVerticesSPen[2] = size(SPenTipVerts) / (floatsPerVertex + floatsPerNormal + floatsPerTexUV);

    glGenVertexArrays(1, &mesh.vao_spen[2]);
    glBindVertexArray(mesh.vao_spen[2]);

    glGenBuffers(1, &mesh.vbo_spen[2]);
    glBindBuffer(GL_ARRAY_BUFFER, mesh.vbo_spen[2]);
    glBufferData(GL_ARRAY_BUFFER, size(SPenTipVerts) * sizeof(SPenTipVerts[0]), &(SPenTipVerts[0]), GL_STATIC_DRAW);

    // Create Vertex Attribute Pointers
    glVertexAttribPointer(0, floatsPerVertex, GL_FLOAT, GL_FALSE, stride, 0);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(1, floatsPerNormal, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* floatsPerVertex));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(2, floatsPerTexUV, GL_FLOAT, GL_FALSE, stride, (void*)(sizeof(float)* (floatsPerVertex + floatsPerNormal)));
    glEnableVertexAttribArray(2);


}


void UDestroyMesh(GLMesh& mesh)
{
    glDeleteVertexArrays(1, &mesh.vao_light);
    glDeleteBuffers(1, &mesh.vbo_light);

    glDeleteVertexArrays(1, &mesh.vao_table);
    glDeleteBuffers(1, &mesh.vbo_table);
    
    glDeleteVertexArrays(1, mesh.vao_tablet);
    glDeleteBuffers(1, mesh.vbo_tablet);

    glDeleteVertexArrays(1, mesh.vao_notebook);
    glDeleteBuffers(1, mesh.vbo_notebook);

    glDeleteVertexArrays(1, mesh.vao_lamp);
    glDeleteBuffers(1, mesh.vbo_lamp);
    
}

/*Generate and load the texture*/
void UCreateTexture(const char* filename, GLuint& textureId)
{
    int width, height, channels;
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);

        glGenTextures(1, &textureId);
        glBindTexture(GL_TEXTURE_2D, textureId);

        // set the texture wrapping parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
        // set texture filtering parameters
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
        glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

        gTexWrapMode = GL_REPEAT;

        if (channels == 3) {
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
        }
        
        else if (channels == 4) {
            glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
        }
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            exit(EXIT_FAILURE);
        }

        glGenerateMipmap(GL_TEXTURE_2D);

        stbi_image_free(image);
        glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture
        return;
    }

    cout << "Failed to load texture " << filename << endl;
    // Error loading the image
    //return false;
    exit(EXIT_FAILURE);
}

void UDestroyTexture(GLuint textureId)
{
    glGenTextures(1, &textureId);
}



// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, GLuint& programId)
{
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // Create a Shader program object.
    programId = glCreateProgram();

    // Create the vertex and fragment shader objects
    GLuint vertexShaderId = glCreateShader(GL_VERTEX_SHADER);
    GLuint fragmentShaderId = glCreateShader(GL_FRAGMENT_SHADER);

    // Retrive the shader source
    glShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    glShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    glCompileShader(vertexShaderId); // compile the vertex shader
    // check for shader compile errors
    glGetShaderiv(vertexShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glCompileShader(fragmentShaderId); // compile the fragment shader
    // check for shader compile errors
    glGetShaderiv(fragmentShaderId, GL_COMPILE_STATUS, &success);
    if (!success)
    {
        glGetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Attached compiled shaders to the shader program
    glAttachShader(programId, vertexShaderId);
    glAttachShader(programId, fragmentShaderId);

    glLinkProgram(programId);   // links the shader program
    // check for linking errors
    glGetProgramiv(programId, GL_LINK_STATUS, &success);
    if (!success)
    {
        glGetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    glUseProgram(programId);    // Uses the shader program

    return true;
}


void UDestroyShaderProgram(GLuint programId)
{
    glDeleteProgram(programId);
}




// Open cylinder function
vector<GLfloat> createOpenCylinderVerts(GLfloat posX, GLfloat posY, GLfloat posZ, GLfloat topRadius, GLfloat bottomRadius, GLfloat height, GLfloat trianglePresicion, GLboolean top) {
    vector<GLfloat> openCylinderVerts;
    // Rotation
    GLfloat angle = glm::radians(360.0f) / trianglePresicion;

    // CIRCLE VERTICES............................................
    // ...............................................................
    
    // location and texture coordinates
    GLfloat x, y, z, u, v;

    // Center vertex does not change, only depends wheter it goes on the top or bottom
    if (top == GL_TRUE) {
        z = height + posZ;
    }
    else {
        z = posZ;
    }
    const vector<GLfloat> CENTER = {posX, posY, z, // location
                                    0.0f, 0.0f, 1.0f,   // normal
                                    0.5f, 0.5f};        // u, v
    vector<GLfloat> circleNorm = {0.0f, 0.0f, 1.0f};    // normals are the same along flat circle surface
    
    
    // Creates 3 vertices of a triangle each iteration
    for (int i = 0; i < trianglePresicion; i++) {
        // First vertex of triangle
        openCylinderVerts.insert(openCylinderVerts.end(), CENTER.begin(), CENTER.end()); // Originates at center of circle, location, norm and texture included

        // Second vertex of triangle
        // location
        x = posX + topRadius * cos(angle * (i));
        y = posY + topRadius * sin(angle * (i));
        openCylinderVerts.push_back(x);
        openCylinderVerts.push_back(y);
        openCylinderVerts.push_back(z);
        // norm
        openCylinderVerts.insert(openCylinderVerts.end(), circleNorm.begin(), circleNorm.end());
        // texture
        u = 0.5 + 0.5 * cos(angle * (i));
        v = 0.5 + 0.5 * sin(angle * (i));
        openCylinderVerts.push_back(u);
        openCylinderVerts.push_back(v);

        // Third vertex of triangle
        // location
        x = posX + topRadius * cos(angle * (i + 1));
        y = posY + topRadius * sin(angle * (i + 1));
        openCylinderVerts.push_back(x);
        openCylinderVerts.push_back(y);
        openCylinderVerts.push_back(z);
        // norm
        openCylinderVerts.insert(openCylinderVerts.end(), circleNorm.begin(), circleNorm.end());
        // texture
        u = 0.5 + 0.5 * cos(angle * (i + 1));
        v = 0.5 + 0.5 * sin(angle * (i + 1));
        openCylinderVerts.push_back(u);
        openCylinderVerts.push_back(v);
    }


    // CYLINDER SIDE VERTICES.........................................
    // ...............................................................
    // location coordinates for each triangle vertex per surface, some coordinates will repeat
    GLfloat x1, x2, x3, x4, y1, y2, y3, y4, z1, z2, z3, z4;
    // Vector containing calculated normals
    glm::vec3 sideNorm;
    // Texture coordinate change from surface to surface
    GLfloat textureStep = 1.0f / trianglePresicion;

    z = posZ; // bottom

    // Creates two triangles with three vertices each to form a square flat section of surface
    for (int i = 0; i < trianglePresicion; i++) {
        // Locations, each square section is formed by 4 points, 2 points will repeat to form a different triangle
        // Point 1
        x1 = posX + topRadius * cos(angle * (i));
        y1 = posY + topRadius * sin(angle * (i));
        z1 = height + z;
        // Point 2
        x2 = posX + bottomRadius * cos(angle * (i));;
        y2 = posY + bottomRadius * sin(angle * (i));
        z2 = z;
        // Point 3
        x3 = posX + bottomRadius * cos(angle * (i + 1));
        y3 = posY + bottomRadius * sin(angle * (i + 1));
        z3 = z;
        // Point 4
        x4 = posX + topRadius * cos(angle * (i + 1));
        y4 = posY + topRadius * sin(angle * (i + 1));
        z4 = height + z;

        // Normals, they will be the same in each point of the same surface. Calculated by normalizing cross product of 2 vertices
        sideNorm = glm::normalize(glm::cross(glm::vec3(x2 - x1, y2 - y1, z2 - z1), glm::vec3(x3 - x2, y3 - y2, z3 - z2)));

        // Triangle 1
        // Vertex1
        openCylinderVerts.push_back(x1);
        openCylinderVerts.push_back(y1);
        openCylinderVerts.push_back(z1);
        openCylinderVerts.push_back(sideNorm[0]);
        openCylinderVerts.push_back(sideNorm[1]);
        openCylinderVerts.push_back(sideNorm[2]);
        openCylinderVerts.push_back(0.0f + textureStep * (i));
        openCylinderVerts.push_back(1.0f);
        // Vertex2
        openCylinderVerts.push_back(x2);
        openCylinderVerts.push_back(y2);
        openCylinderVerts.push_back(z2);
        openCylinderVerts.push_back(sideNorm[0]);
        openCylinderVerts.push_back(sideNorm[1]);
        openCylinderVerts.push_back(sideNorm[2]);
        openCylinderVerts.push_back(0.0f + textureStep * (i));
        openCylinderVerts.push_back(0.0f);
        // Vertex3
        openCylinderVerts.push_back(x3);
        openCylinderVerts.push_back(y3);
        openCylinderVerts.push_back(z3);
        openCylinderVerts.push_back(sideNorm[0]);
        openCylinderVerts.push_back(sideNorm[1]);
        openCylinderVerts.push_back(sideNorm[2]);
        openCylinderVerts.push_back(0.0f + textureStep * (i + 1));
        openCylinderVerts.push_back(0.0f);

        // Triangle 2
        // Vertex1
        openCylinderVerts.push_back(x1);
        openCylinderVerts.push_back(y1);
        openCylinderVerts.push_back(z1);
        openCylinderVerts.push_back(sideNorm[0]);
        openCylinderVerts.push_back(sideNorm[1]);
        openCylinderVerts.push_back(sideNorm[2]);
        openCylinderVerts.push_back(0.0f + textureStep * (i));
        openCylinderVerts.push_back(1.0f);
        // Vertex3
        openCylinderVerts.push_back(x3);
        openCylinderVerts.push_back(y3);
        openCylinderVerts.push_back(z3);
        openCylinderVerts.push_back(sideNorm[0]);
        openCylinderVerts.push_back(sideNorm[1]);
        openCylinderVerts.push_back(sideNorm[2]);
        openCylinderVerts.push_back(0.0f + textureStep * (i + 1));
        openCylinderVerts.push_back(0.0f);
        // Vertex4
        openCylinderVerts.push_back(x4);
        openCylinderVerts.push_back(y4);
        openCylinderVerts.push_back(z4);
        openCylinderVerts.push_back(sideNorm[0]);
        openCylinderVerts.push_back(sideNorm[1]);
        openCylinderVerts.push_back(sideNorm[2]);
        openCylinderVerts.push_back(0.0f + textureStep * (i + 1));
        openCylinderVerts.push_back(1.0f);
    }
    return openCylinderVerts;
}


vector<GLfloat> createTorusVerts(GLfloat posX, GLfloat posY, GLfloat posZ, GLfloat mainRadius, GLfloat innerRadius, GLfloat trianglePresicion) {
    vector<GLfloat> torusVerts;
    // Rotation
    GLfloat mainAngle = glm::radians(360.0f) / trianglePresicion;
    GLfloat innerAngle = glm::radians(360.0f) / trianglePresicion;

    // location coordinates for each triangle vertex per surface, some coordinates will repeat
    GLfloat x1, x2, x3, x4, y1, y2, y3, y4, z1, z2, z3, z4;
    // Vector containing calculated normals
    glm::vec3 norm;
    // Texture coordinate change from surface to surface
    GLfloat textureStep = 1.0f / trianglePresicion;

    //z = posZ; // bottom

    // Creates two triangles with three vertices each to form a square flat section of surface
    for (int i = 0; i < trianglePresicion; i++) {
        for (int j = 0; j < trianglePresicion; j++) {
            // Locations, each square section is formed by 4 points, 2 points will repeat to form a different triangle
            // Point 1
            x1 = posX + (mainRadius + innerRadius * cos(innerAngle * (j))) * cos(mainAngle * (i));
            y1 = posY + (mainRadius + innerRadius * cos(innerAngle * (j))) * sin(mainAngle * (i));
            z1 = posZ + innerRadius * sin(innerAngle * (j));
            // Point 2
            x2 = posX + (mainRadius + innerRadius * cos(innerAngle * (j))) * cos(mainAngle * (i + 1));
            y2 = posY + (mainRadius + innerRadius * cos(innerAngle * (j))) * sin(mainAngle * (i + 1));
            z2 = posZ + innerRadius * sin(innerAngle * (j));
            // Point 3
            x3 = posX + (mainRadius + innerRadius * cos(innerAngle * (j + 1))) * cos(mainAngle * (i + 1));
            y3 = posY + (mainRadius + innerRadius * cos(innerAngle * (j + 1))) * sin(mainAngle * (i + 1));
            z3 = posZ + innerRadius * sin(innerAngle * (j + 1));
            // Point 4
            x4 = posX + (mainRadius + innerRadius * cos(innerAngle * (j + 1))) * cos(mainAngle * (i));
            y4 = posY + (mainRadius + innerRadius * cos(innerAngle * (j + 1))) * sin(mainAngle * (i));
            z4 = posZ + innerRadius * sin(innerAngle * (j + 1));

            // Normals, they will be the same in each point of the same surface. Calculated by normalizing cross product of 2 vertices
            norm = glm::normalize(glm::cross(glm::vec3(x2 - x1, y2 - y1, z2 - z1), glm::vec3(x3 - x2, y3 - y2, z3 - z2)));

            // Triangle 1
            // Vertex1
            torusVerts.push_back(x1);
            torusVerts.push_back(y1);
            torusVerts.push_back(z1);
            torusVerts.push_back(norm[0]);
            torusVerts.push_back(norm[1]);
            torusVerts.push_back(norm[2]);
            torusVerts.push_back(textureStep * (i));
            torusVerts.push_back(0.5f + textureStep * (j));
            // Vertex2
            torusVerts.push_back(x2);
            torusVerts.push_back(y2);
            torusVerts.push_back(z2);
            torusVerts.push_back(norm[0]);
            torusVerts.push_back(norm[1]);
            torusVerts.push_back(norm[2]);
            torusVerts.push_back(textureStep * (i + 1));
            torusVerts.push_back(0.5f + textureStep * (j));
            // Vertex3
            torusVerts.push_back(x3);
            torusVerts.push_back(y3);
            torusVerts.push_back(z3);
            torusVerts.push_back(norm[0]);
            torusVerts.push_back(norm[1]);
            torusVerts.push_back(norm[2]);
            torusVerts.push_back(textureStep * (i + 1));
            torusVerts.push_back(0.5f + textureStep * (j + 1));

            // Triangle 2
            // Vertex1
            torusVerts.push_back(x1);
            torusVerts.push_back(y1);
            torusVerts.push_back(z1);
            torusVerts.push_back(norm[0]);
            torusVerts.push_back(norm[1]);
            torusVerts.push_back(norm[2]);
            torusVerts.push_back(textureStep * (i));
            torusVerts.push_back(0.5f + textureStep * (j));
            // Vertex3
            torusVerts.push_back(x3);
            torusVerts.push_back(y3);
            torusVerts.push_back(z3);
            torusVerts.push_back(norm[0]);
            torusVerts.push_back(norm[1]);
            torusVerts.push_back(norm[2]);
            torusVerts.push_back(textureStep * (i + 1));
            torusVerts.push_back(0.5f + textureStep * (j + 1));
            // Vertex4
            torusVerts.push_back(x4);
            torusVerts.push_back(y4);
            torusVerts.push_back(z4);
            torusVerts.push_back(norm[0]);
            torusVerts.push_back(norm[1]);
            torusVerts.push_back(norm[2]);
            torusVerts.push_back(textureStep * (i));
            torusVerts.push_back(0.5f + textureStep * (j + 1));
        }
        
    }
    return torusVerts;
}